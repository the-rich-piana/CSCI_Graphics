HW3 Scene -- Giuliano Costa

Controls:
Arrow keys: Rotate perspective camera
W/A:        Zoom in and Out

Scene of a few trees in Fall. Made with cylinders and draw quads. I seem to have made a mistake somewhere with the perspective camera rotations. But otherwise everything works fine.