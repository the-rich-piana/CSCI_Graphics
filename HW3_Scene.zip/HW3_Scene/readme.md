3D scene of a strange looking solar system with planes. Use arrow keys to change view angle. And press 0 to reset view angle. 

Aspect ratio seems to be causing an issue. I must have made a mistake somewhere.
Also tried to implement a camera translation using WASD keys. But it does not seem to
be effecting the perspective camera.