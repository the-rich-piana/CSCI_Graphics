
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <math.h>

#define GL_GLEXT_PROTOTYPES
#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

int theta =0;
int phi =0;         
int axes=1;       
int mode=0;       
int fov = 70;
int asp = 1;
int dim = 30;

double Exx = -1;
double Eyy = 1;
double Ezz = 1;
//  Cosine and Sine in degrees

#define Cos(x) (cos((x)*3.14 / 180))
#define Sin(x) (sin((x)*3.14 / 180))

#define LEN 8192  //  Maximum lengthetaof text string
void Print(const char* format , ...)
{
   char    buf[LEN];
   char*   ch=buf;
   va_list args;
   va_start( args, format);
   vsnprintf(buf, LEN, format, args);
   va_end(args);
   while (*ch)
      glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, *ch++);
}


static void drawSphere(double x, double y, double z, double cx, double cy, double cz, double r) 
{
   int th, ph;

   glPushMatrix();
   glTranslated(x, y, z);
   glScaled(r, r, r); //radius

   int divisions = 1;
    //Quad strips
   for (ph=-90; ph<90; ph += divisions){
      glBegin(GL_QUAD_STRIP);

      for (th=0; th<=360; th += divisions){
         glColor3f(cx, Sin(ph)*cy, cz);
         glVertex3d(Sin(th)*Cos(ph) , Sin(ph) , Cos(th)*Cos(ph));
         glVertex3d(Sin(th)*Cos(ph+divisions) , Sin(ph+divisions) , Cos(th)*Cos(ph+divisions));
      }
      glEnd();
   }

   glPopMatrix();
}

/*
 *  OpenGL (GLUT) calls this routine to display the scene
 */
void display()
{
   glClear(GL_COLOR_BUFFER_BIT|GL_DEPTH_BUFFER_BIT);
  glLoadIdentity(); //loads identity matrix to clear previous transformations
  double Ex = Exx*dim*Sin(theta)*Cos(phi);
  double Ey = Eyy*dim        *Sin(phi);
  double Ez = Ezz*dim*Cos(theta)*Cos(phi);
    gluLookAt(Exx*dim*Sin(theta)*Cos(phi) ,Eyy*dim        *Sin(phi), Ezz*dim*Cos(theta)*Cos(phi) , 0,0,0 , 0,Cos(phi),0); //Perspective code borrowed from ex9   
   glRotatef(phi, 1, 0, 0);
   glRotatef(theta, 0, 1, 0);
   glEnable(GL_DEPTH_TEST); //Enable z buffering
   const double axis_len = 1;  //  Length aof axes

    drawSphere(1, 0, 0, 1, 1, 1, 1);
    drawSphere(-10, 5, 0, 1, 1, 0.1, 1.5);
    drawSphere(-10, 1, 0, 0.6, 1, 0.1, 1);
    drawSphere(-1, -1, 0, 1, 1, 0.1, 1.5);

    glColor3f(1,1,1);
    glBegin(GL_QUADS);

    glVertex3f(5.0,0,-1.0);
    glVertex3f(5.0,-10,-1.0);
    glVertex3f(3.0,-10,-4.0);
    glVertex3f(3.0,0,-4.0);
    glColor3f(0.8,0.8,0.8);

    glVertex3f(60.0,0,-1.0);
    glVertex3f(60.0,-10,-1.0);
    glVertex3f(40.0,-10,-4.0);
    glVertex3f(40.0,0,-4.0);
    glColor3f(0.8,0.8,0.8);

    glVertex3f(15.0,0,-1.0);
    glVertex3f(15.0,-10,-1.0);
    glVertex3f(5.0,-10,-4.0);
    glVertex3f(5.0,0,-4.0);
    glColor3f(0.8,0.8,0.8);

    glVertex3f(-8.0,0,-1.0);
    glVertex3f(-8.0,-10,-1.0);
    glVertex3f(-5.0,-10,-4.0);
    glVertex3f(-5.0,0,-4.0);
    glColor3f(0.8,0.8,0.8);    

    glVertex3f(5.0,0,-1.0);
    glVertex3f(5.0,-10,-1.0);
    glVertex3f(3.0,-10,-4.0);
    glVertex3f(3.0,0,-4.0);
    glColor3f(0.8,0.8,0.8);

    glVertex3f(-5.0,0,-1.0);
    glVertex3f(-5.0,-1.0,-1.0);
    glVertex3f(-3.0,-1.0,-4.0);
    glVertex3f(-3.0,0,-4.0);

    glEnd();
   //  Draw axes
   glColor3f(1,1,1);
   if (axes)
   {
      glBegin(GL_LINES);
      glVertex3d(0.0,0.0,0.0);
      glVertex3d(axis_len,0.0,0.0);
      glVertex3d(0.0,0.0,0.0);
      glVertex3d(0.0,axis_len,0.0);
      glVertex3d(0.0,0.0,0.0);
      glVertex3d(0.0,0.0,axis_len);
      glEnd();
      //  Label axes
      glRasterPos3d(axis_len,0.0,0.0);
      Print("X");
      glRasterPos3d(0.0,axis_len,0.0);
      Print("Y");
      glRasterPos3d(0.0,0.0,axis_len);
      Print("Z");
   }
   //  Five pixels from the lower left corner of the window
   glWindowPos2i(5,5);
   //  Print the text string
//   Print("Angle=%d,%d Sigma=%d, beta=%f, rho=%d", theta,phi, (int)s, b, (int)r);//ADD VALUES HERE

   glFlush();
   glutSwapBuffers();
}

static void Project()
{
   glMatrixMode(GL_PROJECTION);
   glLoadIdentity();

   gluPerspective(fov, asp,dim/4,4*dim);

    //glOrtho(-asp*dim,+asp*dim, -dim,+dim, -dim,+dim);
   //  Switch to manipulating the model matrix
   glMatrixMode(GL_MODELVIEW);
   glLoadIdentity();
}

int x, y, z=0;
void special(int key, int x, int y)
{
   if (key == GLUT_KEY_RIGHT)
      theta+= 2;   //  Left arrow key - decrease angle by 5 degrees
   else if (key == GLUT_KEY_LEFT)
      theta-= 2;
   else if (key == GLUT_KEY_UP)
      phi += 2;
   else if (key == GLUT_KEY_DOWN)
      phi -= 2;
 
   theta %= 360;
   phi %= 360;
   Project();
   glutPostRedisplay();
}

void key(unsigned char ch,int x,int y)
{
   if (ch == '0')
      theta= phi= 0;
    else if(ch == 'w'){
        Exx += .1;
    }
    else if(ch == 's'){
        Exx -= .1;
    }    
    else if(ch == 'a'){
        Eyy += .1;
    }  
    else if(ch == 'd'){
        Eyy -= .1;
    }            
    Project();
   glutPostRedisplay();
}

void reshape(int width,int height)
{
    glViewport(1, 1, width,height);
    //gluPerspective(fov, asp, dim/4,4*dim);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(-dim*asp,+dim*asp, -dim,+dim, -dim,+dim);   
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    Project();
}

/*
 *  Start up GLUT and tell it what to do
 */
int main(int argc,char* argv[])
{
   glutInit(&argc,argv);
   glutInitDisplayMode(GLUT_RGB | GLUT_DEPTH | GLUT_DOUBLE);
   glutInitWindowSize(720 * 2, 480 *2);
   glutCreateWindow("Scene");
   glutDisplayFunc(display);
   glutReshapeFunc(reshape);
   glutSpecialFunc(special);
   glutKeyboardFunc(key);
   glutMainLoop();

   return 0;
}