HW5 Lighting -- Giuliano Costa

Key Bindings:

- WASD    First person movement keys
- z/x     Change FOV
- m       Toggle ortho/persp mode
- f       Toggle first person veiw on and off (higher priority than the other two view modes)
- 9          Toggle axes
- arrows     Change view angle
- PgDn/PgUp  Zoom in and out
- 0          Reset view angle
- ESC        Exit
 
Lighting Controls:
- Space     Toggle light rotation
- < / >     Move left/right

Default window size is 1920x1080
Default camera view is perspective with an FOV of 70.

Scene is modified from HW4. I notice that the XY planes have trouble calculating the correct normals. Despite me
setting them to (0,1,0). I'm not really sure why there are lines that show up. My guess is something to do with the
smooth shading. Could also be related to diffuse/spec material. I spent about 5 hours on this assignment.